package Hospital.auth.controller;

import Hospital.auth.model.User;
import Hospital.auth.security.jwt.JwtService;
import Hospital.auth.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/auth")
@Tag(name = "Autenticación", description = "Controlador para el registro, inicio de sesión y validación de tokens de usuarios con soporte HATEOAS")
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtService jwtService;
    private final UserService userService;

    public AuthController(AuthenticationManager authManager, JwtService jwtService, UserService userService) {
        this.authManager = authManager;
        this.jwtService = jwtService;
        this.userService = userService;
    }

    @Operation(summary = "Registrar un nuevo usuario", description = "Crea una nueva cuenta de usuario en el sistema, asignándole un rol y proveyendo enlaces HATEOAS.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Usuario registrado exitosamente con enlaces de navegación",
                    content = @Content(mediaType = "application/json", schema = @Schema(example = "{\"message\":\"Usuario registrado correctamente\",\"role\":\"USER\",\"_links\":{\"self\":{\"href\":\"http://localhost:8080/api/v1/auth/register\"},\"login\":{\"href\":\"http://localhost:8080/api/v1/auth/login\"}}}"))),
            @ApiResponse(responseCode = "400", description = "Datos de entrada inválidos o faltantes"),
            @ApiResponse(responseCode = "409", description = "Conflicto: El nombre de usuario ya se encuentra registrado")
    })
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        try {
            String username = body.get("username");
            String password = body.get("password");
            String role = body.getOrDefault("role", "USER");

            if (username == null || password == null || username.isBlank() || password.isBlank()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Username y password son requeridos"));
            }

            if (!role.equals("USER") && !role.equals("ADMIN")) {
                role = "USER";
            }

            userService.register(username, password, role);

            // Construir respuesta base
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Usuario registrado correctamente");
            response.put("role", role);

            // Crear el EntityModel HATEOAS usando la respuesta base
            EntityModel<Map<String, Object>> entityModel = EntityModel.of(response);

            // Añadir enlaces relacionales externos e internos
            entityModel.add(linkTo(methodOn(AuthController.class).register(null)).withSelfRel());
            entityModel.add(linkTo(methodOn(AuthController.class).login(null)).withRel("login"));

            return ResponseEntity.ok(entityModel);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("error", "El usuario ya existe"));
        }
    }

    @Operation(summary = "Iniciar sesión", description = "Autentica al usuario con sus credenciales, retorna un token JWT válido y enlaces HATEOAS.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Autenticación exitosa, retorna el token generado y enlaces relacionales",
                    content = @Content(mediaType = "application/json", schema = @Schema(example = "{\"token\":\"eyJhbGciOi...\",\"username\":\"juan.perez\",\"role\":\"USER\",\"_links\":{\"self\":{\"href\":\"http://localhost:8080/api/v1/auth/login\"},\"validate\":{\"href\":\"http://localhost:8080/api/v1/auth/validate\"}}}"))),
            @ApiResponse(responseCode = "401", description = "Credenciales incorrectas o inválidas")
    })
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        try {
            String username = body.get("username");
            String password = body.get("password");

            Authentication auth = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username, password));

            if (auth.isAuthenticated()) {
                User user = userService.findByUsername(username)
                        .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

                String token = jwtService.generateToken(username, user.getRole());

                // Construir respuesta base
                Map<String, Object> response = new HashMap<>();
                response.put("token", token);
                response.put("username", username);
                response.put("role", user.getRole());

                // Crear el EntityModel HATEOAS
                EntityModel<Map<String, Object>> entityModel = EntityModel.of(response);

                // Enlaces dinámicos
                entityModel.add(linkTo(methodOn(AuthController.class).login(null)).withSelfRel());
                entityModel.add(linkTo(methodOn(AuthController.class).validateToken()).withRel("validate"));

                return ResponseEntity.ok(entityModel);
            }

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Credenciales inválidas"));

        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Usuario o contraseña incorrectos"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error al procesar la solicitud"));
        }
    }

    @Operation(summary = "Validar token", description = "Verifica si el token JWT sigue siendo válido, adjuntando enlaces de navegación.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "El token es válido",
                    content = @Content(mediaType = "application/json", schema = @Schema(example = "{\"valid\":true,\"_links\":{\"self\":{\"href\":\"http://localhost:8080/api/v1/auth/validate\"}}}")))
    })
    @GetMapping("/validate")
    public ResponseEntity<?> validateToken() {
        Map<String, Object> response = new HashMap<>();
        response.put("valid", true);

        EntityModel<Map<String, Object>> entityModel = EntityModel.of(response);
        entityModel.add(linkTo(methodOn(AuthController.class).validateToken()).withSelfRel());

        return ResponseEntity.ok(entityModel);
    }
}
