package Hospital.auth.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.springframework.hateoas.RepresentationModel;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "users")
@Schema(description = "Entidad que representa a un usuario registrado en el sistema para la autenticación")
public class User extends RepresentationModel<User> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador único del usuario",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;

    @Column(unique = true, nullable = false, length = 50)
    @NotBlank
    @Size(max = 50)
    @Schema(
            description = "Nombre de usuario único para iniciar sesión",
            example = "juan.perez",
            maxLength = 50,
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String username;

    @Column(nullable = false)
    @NotBlank
    @Schema(
            description = "Contraseña encriptada del usuario",
            example = "$2a$10$e0myZ...",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String password;

    @Column(nullable = false, length = 20)
    @NotBlank
    @Size(max = 20)
    @Schema(
            description = "Rol asignado al usuario para el control de acceso",
            example = "ADMIN",
            maxLength = 20,
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String role; // "ADMIN" o "USER"
}
