package Hospital.paciente.controller;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import Hospital.paciente.model.Paciente;
import Hospital.paciente.service.PacienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/pacientes")
@RequiredArgsConstructor
public class PacienteController {


    private final PacienteService service;

    @Operation(
            summary = "Listar pacientes.",
            description = "Entrega una lista con todos los pacientes.")

    @GetMapping
    public ResponseEntity<List<Paciente>> findAll(){
        return ResponseEntity.ok(service.listar());
    }

    @Operation(
            summary = "Buscar paciente..",
            description = "Busca un paciente mediante el Id del mismo.")

    @GetMapping("{id}")
    public ResponseEntity<Paciente> findById(@PathVariable Long id){
        return service.obtenerXId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Crear paciente",
            description = "Registra un nuevo paciente en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Paciente creado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos inválidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })

    @PostMapping
    public ResponseEntity<Paciente> save(@Valid @RequestBody Paciente paciente) {
        Paciente pac = service.save(paciente);
        pac.add(linkTo(methodOn(PacienteController.class).findAll()).withRel("todos"));
        pac.add(linkTo(methodOn(PacienteController.class).findById(pac.getId())).withSelfRel());
        pac.add(linkTo(methodOn(PacienteController.class).updatear(pac)).withRel("update"));
        pac.add(linkTo(methodOn(PacienteController.class).deleteById(pac.getId())).withRel("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(pac);
    }

    @Operation(
            summary = "Actualizar paciente.",
            description = "Actualiza los datos del paciente.")

    @PutMapping
    public ResponseEntity<Paciente> updatear(@Valid @RequestBody Paciente paciente){
        return ResponseEntity.status(HttpStatus.OK).body(service.save(paciente));
    }


    @Operation(
            summary = "Eliminar pacientes.",
            description = "Elimina los pacientes.")

    @DeleteMapping
    public ResponseEntity delete(@RequestBody Paciente paciente){
        service.delete(paciente);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Eliminar por Id.",
            description = "Elimina al paciente segun el Id.")

    @DeleteMapping("{id}")
    public ResponseEntity deleteById(@PathVariable Long id){
        service.borrarXId(id);
        return ResponseEntity.noContent().build();
    }




}
