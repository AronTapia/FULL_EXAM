package Hospital.paciente.service;


import Hospital.paciente.model.Paciente;
import Hospital.paciente.repository.PacienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PacienteService {

    private final PacienteRepository repository;

    public List<Paciente> listar(){
        return repository.findAll();
    }

    public Optional<Paciente> obtenerXId(Long id){
        return repository.findById(id);
    }

    public Paciente save(Paciente paciente){
        return repository.save(paciente);
    }

    public void delete(Paciente paciente){
         repository.delete(paciente);
    }

    public void borrarXId(Long id){
        repository.deleteById(id);
    }

}
