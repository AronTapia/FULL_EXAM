package Hospital.paciente.model;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Enrtidad para representar al paciente registrado en el sistema del hospital.")

public class Paciente extends RepresentationModel<Paciente> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador unico del paciente.",
            example = "1,2,3,etc.",
            accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;
    @Column(length = 8, unique = true)
    @NotBlank
    @Size(max = 8)
    @Schema(description = "RUT sin digito verificador del paciente registrado en el hospital.",
            example = "21630895", maxLength = 8,
            requiredMode = Schema.RequiredMode.REQUIRED)
    private String rut;
    @Column(length = 1)
    @NotBlank
    @Size(max = 2)
    @Schema(description = "Digito verificador del RUT del paciente.",
            example = "1/K",
            maxLength = 1,
            requiredMode = Schema.RequiredMode.REQUIRED)
    private String dv;
    @Column(length = 15)
    @NotBlank
    @Size(max = 15)
    private String priNombre;
    @Column(length = 15)
    @Size(max = 15)
    private String segNombre;
    @Column(length = 15)
    @NotBlank
    @Size(max = 15)
    private String apPaterno;
    @Column(length = 15)
    @NotBlank
    @Size(max = 15)
    private String apMaterno;
    @Column(length = 10)
    @NotBlank
    @Size(max = 10)
    private String fecNac;
    @Column(length = 20)
    @NotBlank
    @Size(max = 20)
    @Schema(description = "Estado en el que se encuentra actualmente el paciente.",
    example = "Sano/En revision/Grave")
    private String estado;
}


