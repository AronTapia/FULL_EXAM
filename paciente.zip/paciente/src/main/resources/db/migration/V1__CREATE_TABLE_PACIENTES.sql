CREATE TABLE paciente (
    id        BIGINT       NOT NULL AUTO_INCREMENT,
    rut       VARCHAR(8)   NOT NULL UNIQUE,
    dv        VARCHAR(1)   NOT NULL,
    pri_nombre VARCHAR(15) NOT NULL,
    seg_nombre VARCHAR(15) ,
    ap_paterno VARCHAR(15) NOT NULL,
    ap_materno VARCHAR(15) NOT NULL,
    fec_nac   VARCHAR(10)  NOT NULL,
    estado    VARCHAR(20)  NOT NULL,

    PRIMARY KEY (id)
);