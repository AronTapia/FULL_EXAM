INSERT INTO paciente (rut, dv, pri_nombre, seg_nombre, ap_paterno, ap_materno, fec_nac, estado)
VALUES
    ('12345678', '9', 'Juan',  'Andrés',  'González', 'Muñoz',   '1990-05-15', 'Activo'),
    ('87654321', 'K', 'María', 'José',    'Pérez',    'Rojas',   '1985-11-23', 'Activo'),
    ('11223344', '5', 'Carlos','Ignacio', 'Martínez', 'Fuentes', '2000-03-08', 'Inactivo');