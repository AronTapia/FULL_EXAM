package Hospital.paciente;

import Hospital.paciente.model.Paciente;
import Hospital.paciente.repository.PacienteRepository;
import Hospital.paciente.service.PacienteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PacienteServiceTest {

    @Mock
    private PacienteRepository repository;

    @InjectMocks
    private PacienteService service;

    private Paciente pacienteEjemplo;

    @BeforeEach
    void setUp() {
        pacienteEjemplo = new Paciente();
        pacienteEjemplo.setId(1L);
        pacienteEjemplo.setRut("127645");
        pacienteEjemplo.setDv("K");
        pacienteEjemplo.setPriNombre("Juan");
        pacienteEjemplo.setApPaterno("Muñoz");
        pacienteEjemplo.setApMaterno("Sepulveda");
        pacienteEjemplo.setEstado("En riesgo");

    }

    @Test
    void listar_DeberiaRetornarListaDePacientes() {

        when(repository.findAll()).thenReturn(List.of(pacienteEjemplo));


        List<Paciente> resultado = service.listar();


        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("Juan Pérez", resultado.get(0).getPriNombre());
        verify(repository, times(1)).findAll(); // Verifica que se llamó una vez
    }

    @Test
    void obtenerXId_CuandoExiste_DeberiaRetornarPaciente() {

        when(repository.findById(1L)).thenReturn(Optional.of(pacienteEjemplo));


        Optional<Paciente> resultado = service.obtenerXId(1L);


        assertTrue(resultado.isPresent());
        assertEquals("Juan Pérez", resultado.get().getPriNombre());
        verify(repository, times(1)).findById(1L);
    }

    @Test
    void obtenerXId_CuandoNoExiste_DeberiaRetornarOptionalVacio() {

        when(repository.findById(2L)).thenReturn(Optional.empty());


        Optional<Paciente> resultado = service.obtenerXId(2L);


        assertTrue(resultado.isEmpty());
        verify(repository, times(1)).findById(2L);
    }

    @Test
    void save_DeberiaGuardarYRetornarPaciente() {

        when(repository.save(any(Paciente.class))).thenReturn(pacienteEjemplo);


        Paciente guardado = service.save(pacienteEjemplo);


        assertNotNull(guardado);
        assertEquals(1L, guardado.getId());
        verify(repository, times(1)).save(pacienteEjemplo);
    }

    @Test
    void delete_DeberiaLlamarAlMetodoDeleteDelRepository() {

        service.delete(pacienteEjemplo);

        verify(repository, times(1)).delete(pacienteEjemplo);
    }

    @Test
    void borrarXId_DeberiaLlamarAlMetodoDeleteByIdDelRepository() {

        service.borrarXId(1L);


        verify(repository, times(1)).deleteById(1L);
    }
}
