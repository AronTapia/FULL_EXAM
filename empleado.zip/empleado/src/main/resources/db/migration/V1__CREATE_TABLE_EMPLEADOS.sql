CREATE TABLE empleado (
    id         BIGINT      NOT NULL AUTO_INCREMENT,
    rut        VARCHAR(8)  NOT NULL UNIQUE,
    dv         VARCHAR(1)  NOT NULL,
    pri_nombre VARCHAR(15) NOT NULL,
    ap_paterno VARCHAR(15) NOT NULL,
    cargo      VARCHAR(50) NOT NULL,

    PRIMARY KEY (id)
);