INSERT INTO empleado (rut, dv, pri_nombre, ap_paterno, cargo)
VALUES
    ('11111111', '1', 'Carlos',  'Ramírez', 'Médico'),
    ('22222222', '2', 'Fernanda','Soto',    'Enfermera'),
    ('33333333', 'K', 'Diego',   'Vargas',  'Administrativo');