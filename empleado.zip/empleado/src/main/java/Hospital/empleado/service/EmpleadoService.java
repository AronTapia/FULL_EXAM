package Hospital.empleado.service;


import Hospital.empleado.model.Empleado;
import Hospital.empleado.repository.EmpleadoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EmpleadoService {

    private final EmpleadoRepository repository;

    public List<Empleado> listar(){
        return repository.findAll();
    }

    public Optional<Empleado> obtenerXId(Long id){
        return repository.findById(id);
    }

    public Empleado save(Empleado empleado){
        return repository.save(empleado);
    }

    public void delete(Empleado empleado){
        repository.delete(empleado);
    }

    public void borrarXId(Long id){
        repository.deleteById(id);
    }
}
