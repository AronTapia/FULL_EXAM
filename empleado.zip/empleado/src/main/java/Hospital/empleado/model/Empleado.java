package Hospital.empleado.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa a un empleado del hospital")
public class Empleado extends RepresentationModel<Empleado> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador único del empleado",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;

    @Column(length = 8, unique = true)
    @NotBlank
    @Size(max = 8)
    @Schema(
            description = "RUT del empleado sin puntos ni dígito verificador",
            example = "12345678",
            maxLength = 8,
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String rut;

    @Column(length = 1)
    @NotBlank
    @Size(max = 1)
    @Schema(
            description = "Dígito verificador del RUT del empleado",
            example = "K",
            maxLength = 1,
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String dv;

    @Column(length = 15)
    @NotBlank
    @Size(max = 15)
    @Schema(
            description = "Primer nombre del empleado",
            example = "Juan",
            maxLength = 15,
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String priNombre;

    @Column(length = 15)
    @NotBlank
    @Size(max = 15)
    @Schema(
            description = "Apellido paterno del empleado",
            example = "Pérez",
            maxLength = 15,
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String apPaterno;

    @Column(length = 50)
    @NotBlank
    @Size(max = 50)
    @Schema(
            description = "Cargo o puesto que ocupa el empleado en el hospital",
            example = "Médico General",
            maxLength = 50,
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String cargo;
}