package Hospital.empleado.controller;

import Hospital.empleado.model.Empleado;
import Hospital.empleado.service.EmpleadoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/empleados")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
public class EmpleadoController {

    private final EmpleadoService service;

    @Operation(
            summary = "Listar todos los empleados",
            description = "Retorna una lista con todos los registros de empleados del sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @GetMapping
    public ResponseEntity<List<Empleado>> findAll(){
        List<Empleado> lista = service.listar();
        for (Empleado e : lista) {
            e.add(linkTo(methodOn(EmpleadoController.class).findById(e.getId())).withSelfRel());
        }
        return ResponseEntity.ok(lista);
    }

    @Operation(
            summary = "Buscar empleado por ID",
            description = "Busca y retorna un registro de empleado específico mediante su identificador único."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Empleado encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos"),
            @ApiResponse(responseCode = "404", description = "Empleado no encontrado")
    })
    @GetMapping("{id}")
    public ResponseEntity<Empleado> findById(@PathVariable Long id){
        return service.obtenerXId(id)
                .map(empleado -> {
                    empleado.add(linkTo(methodOn(EmpleadoController.class).findAll()).withRel("todos"));
                    empleado.add(linkTo(methodOn(EmpleadoController.class).findById(empleado.getId())).withSelfRel());
                    empleado.add(linkTo(methodOn(EmpleadoController.class).updatear(empleado)).withRel("update"));
                    empleado.add(linkTo(methodOn(EmpleadoController.class).deleteById(empleado.getId())).withRel("delete"));
                    return ResponseEntity.ok(empleado);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Crear empleado",
            description = "Registra un nuevo empleado en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Empleado creado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos de entrada inválidos"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<Empleado> save(@Valid @RequestBody Empleado empleado){
        Empleado emp = service.save(empleado);
        emp.add(linkTo(methodOn(EmpleadoController.class).findAll()).withRel("todos"));
        emp.add(linkTo(methodOn(EmpleadoController.class).findById(emp.getId())).withSelfRel());
        emp.add(linkTo(methodOn(EmpleadoController.class).updatear(emp)).withRel("update"));
        emp.add(linkTo(methodOn(EmpleadoController.class).deleteById(emp.getId())).withRel("delete"));
        return ResponseEntity.status(HttpStatus.CREATED).body(emp);
    }

    @Operation(
            summary = "Actualizar empleado",
            description = "Actualiza los datos de un registro de empleado existente."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Empleado actualizado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos de actualización inválidos"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping
    public ResponseEntity<Empleado> updatear(@RequestBody Empleado empleado){
        Empleado emp = service.save(empleado);
        emp.add(linkTo(methodOn(EmpleadoController.class).findAll()).withRel("todos"));
        emp.add(linkTo(methodOn(EmpleadoController.class).findById(emp.getId())).withSelfRel());
        emp.add(linkTo(methodOn(EmpleadoController.class).deleteById(emp.getId())).withRel("delete"));
        return ResponseEntity.ok(emp);
    }

    @Operation(
            summary = "Eliminar empleado por objeto",
            description = "Elimina un registro de empleado enviando el objeto completo en el cuerpo de la petición."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Empleado eliminado correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping
    public ResponseEntity delete(@RequestBody Empleado empleado){
        service.delete(empleado);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Eliminar empleado por ID",
            description = "Elimina un registro de empleado específico usando su identificador en la URL."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Empleado eliminado correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos"),
            @ApiResponse(responseCode = "404", description = "Empleado no encontrado")
    })
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("{id}")
    public ResponseEntity deleteById(@PathVariable Long id){
        service.borrarXId(id);
        return ResponseEntity.noContent().build();
    }
}