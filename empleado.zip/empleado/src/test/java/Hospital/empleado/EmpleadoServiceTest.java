package Hospital.empleado;

import Hospital.empleado.model.Empleado;
import Hospital.empleado.repository.EmpleadoRepository;
import Hospital.empleado.service.EmpleadoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmpleadoServiceTest {

    @Mock
    private EmpleadoRepository repository;

    @InjectMocks
    private EmpleadoService service;

    private Empleado empleadoEjemplo;

    @BeforeEach
    void setUp() {
        // Inicializamos un objeto de prueba antes de cada test
        empleadoEjemplo = new Empleado();
        empleadoEjemplo.setId(1L);
        empleadoEjemplo.setRut("17843750");
        empleadoEjemplo.setDv("8");
         empleadoEjemplo.setPriNombre("Ana");
        empleadoEjemplo.setApPaterno("Manzor");
         empleadoEjemplo.setCargo("Enfermera");
    }

    @Test
    void listar_DeberiaRetornarListaDeEmpleados() {
        when(repository.findAll()).thenReturn(List.of(empleadoEjemplo));


        List<Empleado> resultado = service.listar();


        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals(1L, resultado.get(0).getId());
        verify(repository, times(1)).findAll();
    }

    @Test
    void obtenerXId_CuandoExiste_DeberiaRetornarEmpleado() {

        when(repository.findById(1L)).thenReturn(Optional.of(empleadoEjemplo));


        Optional<Empleado> resultado = service.obtenerXId(1L);


        assertTrue(resultado.isPresent());
        assertEquals(1L, resultado.get().getId());
        verify(repository, times(1)).findById(1L);
    }

    @Test
    void obtenerXId_CuandoNoExiste_DeberiaRetornarOptionalVacio() {

        when(repository.findById(99L)).thenReturn(Optional.empty());


        Optional<Empleado> resultado = service.obtenerXId(99L);


        assertTrue(resultado.isEmpty());
        verify(repository, times(1)).findById(99L);
    }

    @Test
    void save_DeberiaGuardarYRetornarEmpleado() {

        when(repository.save(any(Empleado.class))).thenReturn(empleadoEjemplo);


        Empleado guardado = service.save(empleadoEjemplo);


        assertNotNull(guardado);
        assertEquals(1L, guardado.getId());
        verify(repository, times(1)).save(empleadoEjemplo);
    }

    @Test
    void delete_DeberiaLlamarAlMetodoDeleteDelRepository() {

        service.delete(empleadoEjemplo);


        verify(repository, times(1)).delete(empleadoEjemplo);
    }

    @Test
    void borrarXId_DeberiaLlamarAlMetodoDeleteByIdDelRepository() {

        service.borrarXId(1L);


        verify(repository, times(1)).deleteById(1L);
    }
}